/*
 for someplatforms it's needed to inject replace.h into
 the iniparser source code
 --metze
*/
#include "../replace/replace.h"
#include "../iniparser/src/strlib.c"
