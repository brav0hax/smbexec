#include "localedir.h"

const char *dyn_LOCALEDIR = LOCALEDIR;
